require File.dirname(__FILE__) + '/../spec_helper'

context "A UserNotifier on signup_notification" do
  setup do
    set_mailer_in_test
    
    @user = mock("user")
    @user.stub!(:email).and_return('user@test.com')
    @user.stub!(:activation_code).and_return('code')
    @user.stub!(:login).and_return('user')
    @user.stub!(:password).and_return('password')
    
    @user_notifier = UserNotifier.create_signup_notification(@user)
  end
  
  specify "should set @recipients to user's email" do
    @user_notifier.to.should eql( ["user@test.com"] )
  end
  
  specify "should set @subject to [YOURSITE] Please activate your new account" do
    @user_notifier.subject.should eql( "YOURSITE Please activate your new account" )
  end
  
  specify "should set @from to ADMINEMAIL" do
    @user_notifier.from.should eql( ["ADMINEMAIL"])
  end
  
  specify "should contain login reminder (User: user) in mail body" do
    @user_notifier.body.should match( /Username: user/ )
  end
  
  specify "should contain password reminder (Password: password) in mail body" do
    @user_notifier.body.should match( /Password: password/ )
  end
  
  specify "should contain user activation url (http://YOURSITE/activate/code) in mail body" do
    @user_notifier.body.should match( %r{http://YOURSITE/activate/code} )
  end
end

context "A UserNotifier on activation" do
  setup do
    set_mailer_in_test
    
    @user = mock("user")
    @user.stub!(:email).and_return('user@test.com')
    @user.stub!(:login).and_return('user')
    
    @user_notifier = UserNotifier.create_activation(@user)
  end
  
  specify "should set @recipients to user's email" do
    @user_notifier.to.should eql( ["user@test.com"])
  end
  
  specify "should set @subject to [YOURSITE] Your account has been activated!" do
    @user_notifier.subject.should eql( "[YOURSITE] Your account has been activated!")
  end
  
  specify "should set @from to ADMINEMAIL" do
    @user_notifier.from.should eql( ["ADMINEMAIL"])
  end
  
  specify "should contain login reminder (user,) in mail body" do
    @user_notifier.body.should match( %r{user,})
  end
  
  specify "should contain website url (http://YOURSITE/) in mail body" do
    @user_notifier.body.should match( %r{http://YOURSITE/})
  end
end