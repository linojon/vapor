require File.dirname(__FILE__) + '/../spec_helper'

context "A UserObserver" do
  setup do
    @user = mock('user')
    @user_observer = UserObserver.instance
  end

  specify "should call UserNotifier.deliver_signup_notification on user creation" do
    UserNotifier.should_receive(:deliver_signup_notification).with(@user)
    @user_observer.after_create(@user)
  end
  
  specify "should call UserNotifier.deliver_activation if user was recently activated" do
    UserNotifier.should_receive(:deliver_activation).with(@user)
    @user.stub!(:recently_activated?).and_return(true)
    @user_observer.after_save(@user)
  end
  
  specify "should not call UserNotifier.deliver_activation if user wasn't recently activated" do
    UserNotifier.should_not_receive(:deliver_activation)
    @user.stub!(:recently_activated?).and_return(false)
    @user_observer.after_save(@user)
  end
end